import java.util.Scanner;
 class BellmanFord
{
private int dist[];
private int n;
public static final int MAX_VALUE = 999;
public BellmanFord(int n)
{
this.n=n;
dist = new int[n+1];
}
public void BellmanFordEval(int source,int adjn[][])
{
for(int node = 1;node <= n;node++)
{
dist[node]=MAX_VALUE;
}
dist[source]=0;
for(int node = 1; node <= n-1;node++)
{
for(int sourcenode = 1; sourcenode <= n;sourcenode++)
{
for(int destnode = 1;destnode <= n; destnode++)
{
if(adjn[sourcenode][destnode]!= MAX_VALUE)
{
if(dist[destnode] > dist[sourcenode] + adjn[sourcenode][destnode])
dist[destnode] = dist[sourcenode] + adjn[sourcenode][destnode];
}
}
}
}
for(int sourcenode = 1;sourcenode <= n;sourcenode++)
{
for(int destnode = 1;destnode <= n;destnode++)
{
if(adjn[sourcenode][destnode]!=MAX_VALUE)
{
if(dist[destnode] > dist[sourcenode] + adjn[sourcenode][destnode])
System.out.println("The Graph contains negative edge cycle");
}
}
}
for(int vertex = 1;vertex <= n; vertex++)
{
System.out.println("distance of source "+ source + " to " +vertex + " is " + dist[vertex]);
}
}
public static void main(String args[])
{
int n = 0;
int source;
Scanner sc = new Scanner(System.in);
System.out.println("Enter the number of vertices");
n=sc.nextInt();
int adj[][] = new int[n+1][n+1];
System.out.println("Enter the adjacency matrix");
for(int sourcenode = 1; sourcenode <= n;sourcenode++)
{
for(int destnode = 1;destnode <= n; destnode++)
{
adj[sourcenode][destnode] = sc.nextInt();
if(sourcenode == destnode)
{
adj[sourcenode][destnode] = 0;
continue;
}
if(adj[sourcenode][destnode] == 0)
{
adj[sourcenode][destnode] =MAX_VALUE;
}
}
}
System.out.println("Enter the source vertex");
source = sc.nextInt();
BellmanFord bellmanford = new BellmanFord(n);
bellmanford.BellmanFordEval(source, adj);
sc.close();
}
}




//Enter the number of vertices
//6
//Enter the adjacency matrix
//0 4 0 0 -1 0
//0 0 -1 0 -2 0
//0 0 0 0 0 0
//0 0 0 0 0 0
//0 0 0 -5 0 3
//0 0 0 0 0 0
//Enter the source vertex
//1
//distance of source 1 to 1 is 0
//distance of source 1 to 2 is 4
//distance of source 1 to 3 is 3
//distance of source 1 to 4 is -6
//distance of source 1 to 5 is -1
//distance of source 1 to 6 is 2
